package com.example.kampuskuapp.model


data class Mahasiswa(

    val nomor: String,
    val nama: String,
    val alamat: String,
    val jurusan: String

)